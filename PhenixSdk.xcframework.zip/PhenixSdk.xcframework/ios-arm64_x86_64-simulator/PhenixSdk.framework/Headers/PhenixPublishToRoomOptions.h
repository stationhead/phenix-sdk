/**
 * Copyright 2018 PhenixP2P Inc. Confidential and Proprietary. All Rights Reserved.
 */
#import <Foundation/Foundation.h>

@protocol PhenixPublishToRoomOptions<NSObject>

@end
