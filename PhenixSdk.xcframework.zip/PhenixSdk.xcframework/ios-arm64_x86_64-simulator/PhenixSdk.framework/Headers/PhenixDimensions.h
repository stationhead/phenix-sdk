/**
 * Copyright 2022 Phenix Real Time Solutions, Inc. Confidential and Proprietary. All Rights Reserved.
 */
#include <stddef.h>

struct PhenixDimensions {
  size_t width;
  size_t height;
};
